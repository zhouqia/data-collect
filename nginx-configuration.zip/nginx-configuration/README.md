nginx配置项目
===
> * nginx配置统一管理项目
> * 各业务配置维护拆分管理

> ```
> # 将conf.zip拷贝至nginx安装路径conf文件夹下
> [xxxx``@ipha``-hostname-``1` `bin]$ cd $IPHARM_HOME/soft/nginx/conf
> # 解压conf.zip
> [xxxx``@ipha``-hostname-``1` `bin]$ unzip conf.zip
> # 修改必要的ip/服务配置
> [xxxx``@ipha``-hostname-``1` `bin]$ vi upstream.conf
> ``` 

