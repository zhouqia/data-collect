var printWebInfoUrl = '/hj/api/v1/printWebInfo'
// var printWebInfoUrl = 'http://10.1.1.110:9999/hj/api/v1/printWebInfo?id=22'
/**
 * 页面获取参数方法
 * @param name
 * @returns
 */

function GetQueryString(name) {
    var LocString = String(window.location.href);
    var rs = new RegExp("(^|)" + name + "=([^&]*)(&|$)", "gi").exec(LocString), tmp;
    if (tmp = rs) {
        return decodeURI(tmp[2]);
    }
    // parameter cannot be found
    return "";
}

/**
 * 页面获取参数方法
 * @param string
 * @returns
 */

function GetAtcString(string) {
    if (string) {
        return string
    } else {
        return ""
    }
}


/**
 * 渲染头部
 * @param {*} pageData 页面数据
 */
var setPatientInfo = function (pageData) {
    $('#app .header').append(
        '<div>'
        + '<div class="hosIcon">'
        + '<img src= "' + GetAtcString(pageData.hospitalLogoImageUrl) + '" alt="" srcset="">'
        + '</div>'
        + '<div class="pageTitle">华中科技大学同济医学院附属协和医院 用药服务卡</div>'
        + '<div class="patientInfo">'
        + '<span class="longSpan">'
        + ' 科室：' + GetAtcString(pageData.patient.deptName)
        + '</span>'
        + '<span class="longSpan">'
        + ' 病区：' + GetAtcString(pageData.patient.areaName)
        + '</span>'
        + '<span class="longSpan">'
        + ' 床号：' + GetAtcString(pageData.patient.bedNo)
        + '</span>'
        + '<br>'
        + '<span class="shortSpan">'
        + ' 姓名：' + GetAtcString(pageData.patient.name)
        + '</span>'
        + '<span class="shortSpan">'
        + ' 性别：' + GetAtcString(pageData.patient.sex)
        + '</span>'
        + '<span class="shortSpan">'
        + ' 年龄：' + GetAtcString(pageData.patient.age)
        + '</span>'
        + '</div>'
        + '<div class="patientInfo"><span class="maxSpan"> 临床诊断：' + GetAtcString(pageData.diagnose) + '  </span>'
        + '</div>'
        + '<div class="subDesc">（药品以实物为准，图片仅供参考）</div>'
        + '</div>'
    )
}

/**
 * 渲染表单
 * @param {*} pageData 页面数据
 */
var setDrugList = function (pageData) {
    let tableStr =
        '<table class="main-table">'
        + '<thead>'
        + '<tr class="tabel-header-warp">'
        + '<th class="tabel-header drug">药品名称</th>'
        + '<th class="tabel-header">服药时间</th>'
        + '<th class="tabel-header indication">适应症</th>'
        + '<th class="tabel-header info">注意事项</th>'
        + '</tr>'
        + '</thead>'
        + '<tbody>'

    for (let i = 0; i < pageData.prescriptions.length; i++) {
        tableStr += '<tr>'
            + '<td class= "drug-info-warp">'
            + '<div class="left-img">'
            // + '<img src="http://10.1.1.156:9999/hj/' + pageData.prescriptions[i].drugImageUrl + '" alt="">'
            + '<img src="' + GetAtcString(pageData.prescriptions[i].drugImageUrl) + '" alt="">'
            + '</div>'
            + '<div class="right-info">'
            + '<p>' + GetAtcString(pageData.prescriptions[i].drugName)
            + ' (' + GetAtcString(pageData.prescriptions[i].specification) + ')</p>'
            + '<p>' + GetAtcString(pageData.prescriptions[i].regName) + '</p>'
            + '</div>'
            + '</td>'
            + '<td class="time-desc">'
            + '<p>'
            + GetAtcString(pageData.prescriptions[i].adminRoute)
            + '</p>'
            + '<p>'
            + GetAtcString(pageData.prescriptions[i].adminFrequency)
            + ' 每次'
            + GetAtcString(pageData.prescriptions[i].adminDose)
            + '</p>'
            + '<p>'
            + GetAtcString(pageData.prescriptions[i].adminMethod)
            + '</p>'
            + '</td>'
            + '<td>'
            + GetAtcString(pageData.prescriptions[i].advice)
            + '</td>'
            + '<td>'
            + GetAtcString(pageData.prescriptions[i].infos)
            + '</td>'
            + '</tr > '
    }
    tableStr += '</tbody> </table>'
    $('#app .main-table-warp').append(String(tableStr))
}

$().ready(function () {
    let pageId = GetQueryString("id")
    $.ajax({
        headers: { "Accept": "application/json", },
        type: 'GET',
        url: printWebInfoUrl + '?id=' + pageId,
        crossDomain: true,
        beforeSend: function (xhr) {
            xhr.withCredentials = true;
        },
        success: function (data, textStatus, request) {
            if (data.data) {
                setPatientInfo(data.data)
                setDrugList(data.data)
            } else {
                $('#app .header').append('<div style="display: block; text-align: center; font-size: 16px;}">暂无数据</div>')
            }

        }
    });
})








