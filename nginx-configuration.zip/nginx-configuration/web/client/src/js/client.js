$(function () {
    $.ajaxSetup({
        'contentType': 'application/json;'
    });
    var userId = getQueryString('docId') || getQueryString('userId');
    var userName = getQueryString('userName');
    var organizationCode = getQueryString('organizationCode');
    var deptId = getQueryString('deptId');
    var inPatientArea = getQueryString('inPatientArea');
    var groupId = getQueryString('groupId');

    var auditCenterUrl = '/auditcenter';

    var visaAlias = '双签名'; // 双签别名`
    var cancelAlias = '撤销医嘱'; // 撤销医嘱别名
    var modifyAlias = '修改处方'; // 修改别名
    var sendReason = '发送理由'; // 当药师是选择“打回必须修改”后，“坚持使用”按钮功能隐藏，变成“发送理由”按钮

    var iptIsVerify = null;
    var optIsVerify = null;

    var isUpdate = false;

    var polledGetChatInfo = null;
    var polledChatTask = null;

    $('.username').html(userName);
    $('.usernumber').html(userId);
    /**
     * 框架大小计算
     */
    $(window).resize(function () {
        calcSize();
    });

    function calcSize() {
        var screenW = $(window).width();
        var screenH = $(window).height();

        $('.app-container').width(screenW);
        $('.app-container, .app-panel, .Task-detail').height(screenH);

        /**
         * IE 6 浏览器下 Task-list-container 未设置固定高度，滚动条展示会有问题
         */
        $('.Task-list-container').width(270);
        $('.Task-list-container').height(screenH - 77);

        $('.Task-detail').width(screenW - 270);
        $('.main-info').height(screenH - 145);

        if ($('.main-info')[0].scrollHeight > $('.main-info')[0].offsetHeight) {
            $('.basic-info, table.Task-info, table.engine-msg, .chat-info').width(screenW - 305);
        }
    }

    function fixedBasicInfo() {
        if ($('.main-info').scrollTop() > 30) {
            if ($('.patient-info').width() + $(".phar-info").width() >= $('.basic-info').width()) {
                $(".phar-info").addClass('fix-slimbox');
            }

            $('.basic-info').addClass('_float');
            $('.details-info')[0].style.paddingTop = '50px';
        } else if ($('.main-info').scrollTop() == 0) {
            $('.basic-info').removeClass('_float');
            $(".phar-info").removeClass('fix-slimbox');
            $('.details-info')[0].style.paddingTop = 0;
        }
    }
    $('.main-info').scroll(function () {
        fixedBasicInfo();
    })

    /**
     * 搜索
     */
    $('.search-ipt').on('click', function ($event) {
        if ($event.stopPropagation) {
            // 针对 Mozilla 和 Opera 
            $event.stopPropagation();
        } else if (window.event) {
            // 针对 IE 
            window.event.cancelBubble = true;
        }
        //展开效果
        var oriWidth = $(this).width();
        $('.search-ipt').width(228);
        // var t = setInterval(function () {
        //     if (oriWidth >= 218) {
        //         clearInterval(t);
        //         return;
        //     }
        //     oriWidth = oriWidth + 10;
        //     $('.search-ipt').width(oriWidth);
        // }, 8);
        //初始化input
        if ($(this).val() == '搜索')
            $(this).val('');
    });

    $(document).on('click', function () {
        if ($.trim($('.search-ipt').val())) return;
        $('.search-ipt').val('搜索');
        //收缩效果
        var oriWidth = $('.search-ipt').width();
        $('.search-ipt').width(35);
        // var t = setInterval(function () {
        //     if (oriWidth <= 35) {
        //         clearInterval(t);
        //         return;
        //     }
        //     oriWidth = oriWidth - 10;
        //     $('.search-ipt').width(oriWidth);
        // }, 8);
    });

    $('.reflesh').on('click', function () {
        getCounts();
        loadList();
    })

    $('.search-ipt').on('input propertychange', function () {
        var keyword = $.trim($('.search-ipt').val());

        if (timer) clearInterval(timer);
        timer = setTimeout(function () {
            if (keyword == '搜索') return;
            search(keyword);
        }, 500);

        if (keyword && keyword != '搜索') {
            $('.clear-ipt').show();
        } else {
            $('.clear-ipt').hide();
        }
    });

    $('.clear-ipt').on('click', function () {
        $('.search-ipt').val('');
        $(this).hide();
        search();
    });

    // getReplyMsg => 获取输入理由
    function getReplyMsg() {
        return $('.reply-msg').val() == '如有必要,请输入理由' ? '' : $('.reply-msg').val();
    }

    $('.reply-msg').on('focus', function () {
        // $('.reply-msg').removeClass('tips-text');
        $('.reply-msg').val('').addClass('reply-msg-active');
    });
    $('.reply-msg').on('blur', function () {
        if (!$.trim($('.reply-msg').val())) {
            // $('.reply-msg').addClass('tips-text');
            $('.reply-msg').val('如有必要,请输入理由').removeClass('reply-msg-active').addClass('reply-msg-txt');
        }
    });
    $('.reply-msg').on('input propertychange', function () {
        var msg = $('.reply-msg').val();
        if (msg.length > 200) {
            alert('最多输入200个字符。');
            msg = msg.substr(0, 200);
            $('.reply-msg').val(msg);
        }
    });
    /**
     * 处方列表 & 详情
     */
    var curList = [];
    var timer;
    var searchParam = {
        //status 0 => 未处理 1 => 他人处理 默认不传 => 全部
        status: 0,
        //userId 医生id
        userId: userId,
        //userName 医生姓名
        userName: userName,
        //organizationCode 机构码
        organizationCode: organizationCode,
        //deptId 科室id
        deptId: deptId,
        //inPatientArea
        inPatientArea: inPatientArea,
        //groupId 
        groupId: groupId,
        //nameOrBedno
        nameOrBedno: null
    }
    var currentTask; //选中的处方

    $('.list-panel').on('click', 'li', function () {
        if ($(this).hasClass('active')) return;

        $(this).addClass('active').siblings().removeClass('active');
        //清除当前数据
        $('.Task-list').empty();
        $('.main-info').empty();
        $('.react-module').hide();
        $('.feedback').hide();
        currentTask = null;
        //请求后台数据参数配置
        var idx = $(this).index();
        searchParam.status = idx == 0 ? 0 : (idx == 1 ? 1 : undefined);
        loadList();
    });

    $('.Task-list').on('click', 'li', function () {
        if ($('.Task-list')[0].innerText == '当前没有消息') {
            return;
        }
        $('.react-module').show();
        $('.reply-msg').val('如有必要,请输入理由').addClass('reply-msg-txt');
        if (currentTask) {
            currentTask.replyMsg = getReplyMsg();
        }
        polledGetChatInfo();
        var idx = $(this).index();
        if ($(this).hasClass('active')) return;

        $(this).addClass('active').siblings().removeClass('active');
        // $('.reply-msg').val('').addClass('reply-msg-active');
        currentTask = curList[idx];
        if (currentTask.replyMsg) {
            $('.reply-msg').val(currentTask.replyMsg).removeClass('reply-msg-txt');
        }
        if (currentTask.auditResult.messageStatus) { // currentTask.auditResult.messageStatus 必须修改的情况
            $('.reply-visa').prop('disabled', false).removeClass('disabled');
            // $('div.reply-visa  > button').text(visaAlias);
        } else {
            $('.reply-visa').prop('disabled', true).addClass('disabled');
            // $('div.reply-visa  > button').text(sendReason);
        }

        _feedback();

        if (currentTask.auditResult.source == '门诊' || currentTask.auditResult.source == '急诊') {
            loadRecipeDetail();
        } else {
            loadOrderDetail();
        }

        setTimeout(function () {
            calcSize();
        }, 1000);

    });

    // 获取聊天消息
    var chatMessage = [];
    function getChatMessage(attachKey) {
        var chatParams = '';
        if (currentTask.auditResult.source == '门诊') {
            chatParams = '?hospitalCode=' + organizationCode + '&userId=' + userId + '&source=' + encodeURI(currentTask.auditResult.source) + '&attachKey=' + attachKey;
        } else {
            chatParams = '?hospitalCode=' + organizationCode + '&userId=' + userId + '&source=' + encodeURI(currentTask.auditResult.source) + '&attachKey=' + attachKey + '&attachSecondKey=' + currentTask.auditResult.groupNo;
        }
        var url = auditCenterUrl + '/api/v1/queryChatMessageNoLogin' + chatParams + '&t=' + new Date().getTime();
        $.get(url, function (res) {
            if (res.code == '200') {
                chatMessage = res.data;
                // 加载聊天信息
                loadChatInfo();
            }
        })
    }

    // 发送聊天消息
    function sendChatMessage() {
        if (!$.trim($('.reply-msg').val())) {
            return;
        }
        var params = {
            hospitalCode: organizationCode,
            userId: userId,
            source: currentTask.auditResult.source,
            attachKey: getAttachKey(),
            attachSecondKey: currentTask.auditResult.groupNo,
            message: getReplyMsg(),
            userRole: '医生'
        };
        if (currentTask.auditResult.source == '门诊') {
            delete params.attachSecondKey;
        }
        // var paramList = [];
        // for (var key in params) {
        //     paramList.push(key + '=' + params[key]);
        // }
        $.post(auditCenterUrl + '/api/v1/sendChatMessageNoLogin', JSON.stringify(params), function (json) {
            if (json.code == '200') {
                getChatMessage(params.attachKey);
                $('.reply-msg').val("");
            }
        })
    }

    // 获取 attachKey 门诊是 optRecipeId 住院是 engineId 
    function getAttachKey() {
        switch (currentTask.auditResult.source) {
            case '门诊': return currentTask.auditResult.optRecipeId;
            case '住院': return currentTask.auditResult.engineId;
        }
    }

    // 反馈控制
    function _feedback() {
        if (currentTask.auditResult.rejectStatus != null) {
            $('.feedback').show();
            $('.reply').hide();
            //初始化医生操作记录
            showRejcetInfo();
        } else {
            $('.reply').show();
            $('.feedback').hide();
        }
    };

    //获取数量
    function getCounts() {
        $.post(auditCenterUrl + '/api/v1/reject/backTaskCount?' + '&t=' + new Date().getTime(), JSON.stringify(searchParam), function (json) {
            if (json.code == '200') {
                var counts = json.data || {};
                $('.un-count').html(counts.unCount);
                $('.other-count').html(counts.otherCount);
                $('.total-count').html(counts.count);
            }
        }, "json")
    }

    //搜索
    function search(keyword) {
        // var tempCurList = [];

        // $.each(curList, function(index, value){
        //     var isMatch = false;
        //     isMatch = value.auditResult.name.match(keyword) || isMatch;
        //     optRecipeId = value.auditResult.optRecipeId + '';
        //     isMatch = optRecipeId.match(keyword) || isMatch;
        //     if (isMatch) {
        //         tempCurList.push(value);
        //     }
        // })
        // curList = tempCurList;
        // showList({
        //     data: {
        //         recordList : curList
        //     }
        // }, keyword);
        searchParam.nameOrBedno = keyword ? keyword : undefined;
        loadList(keyword);
    }
    //加载列表
    function loadList(keyword) {
        //loading
        $.post(auditCenterUrl + '/api/v1/reject/backTaskList?' + '&t=' + new Date().getTime(), JSON.stringify(searchParam), function (json) {
            $('.Task-list').empty();
            curList = json.data ? (json.data.recordList != null ? json.data.recordList : []) : [];
            if (json.code != '200') {
                curList = [];
            }

            var list = "";

            if (curList.length <= 0) {
                list += '<li>当前没有消息</li>';
            }

            for (var i = 0; i < curList.length; i++) {
                list += '<li id="' + curList[i].auditResult.id + '">';

                if (curList[i].auditResult.rejectStatus == null) { // curList[i].item.rejectStatus == null
                    list += '   <h3>';
                    list += '   <span class="icon"></span>';
                } else {
                    list += '   <h3 style="display: flex;">';
                }
                if (curList[i].auditResult.source != '住院') {
                    if (keyword) {
                        list += '   <span style="word-break: break-all;flex: 1;">' + highLightText(curList[i].auditResult.name, keyword) + '(' + highLightText(curList[i].auditResult.patientId + '', keyword) + ')  ' + (curList[i].auditResult.sex == '2' ? '女' : curList[i].auditResult.sex == '1' ? '男' : '') + ' ' + curList[i].auditResult.recipeNo + '</span>';
                    } else {
                        list += '   <span style="word-break: break-all;flex: 1;">' + curList[i].auditResult.name + '(' + curList[i].auditResult.patientId + ')  ' + (curList[i].auditResult.sex == '2' ? '女' : curList[i].auditResult.sex == '1' ? '男' : '') + ' ' + curList[i].auditResult.recipeNo + '</span>';
                    }
                    if (curList[i].auditResult.rejectStatus == 1) {
                        list += '   <span class="rejectIcon" style="color: rgb(67,166,73);">' + visaAlias + '</span>';
                    } else if (curList[i].auditResult.rejectStatus == 0) {
                        list += '   <span class="rejectIcon" style="color: rgb(241,106,92);">' + modifyAlias + '</span>';
                    }
                } else {
                    if (keyword) {
                        list += '   <span style="word-break: break-all;flex: 1;">' + curList[i].auditResult.inWardName + ' ' + highLightText(curList[i].auditResult.inWardBedNo, keyword) + '床 ' + highLightText(curList[i].auditResult.name, keyword) + '(' + curList[i].auditResult.patientId + ')' + ' ' + (curList[i].auditResult.sex == 'F' ? '女' : '男') + '</span>';
                    } else {
                        list += '   <span style="word-break: break-all;flex: 1;">' + curList[i].auditResult.inWardName + ' ' + curList[i].auditResult.inWardBedNo + '床 ' + curList[i].auditResult.name + '(' + curList[i].auditResult.patientId + ')' + ' ' + (curList[i].auditResult.sex == 'F' ? '女' : '男') + '</span>';
                    }
                    if (curList[i].auditResult.rejectStatus == 1) {
                        list += '   <span class="rejectIcon" style="color: rgb(67,166,73);">' + visaAlias + '</span>';
                    } else if (curList[i].auditResult.rejectStatus == 2 || curList[i].auditResult.rejectStatus == 0) {
                        list += '   <span class="rejectIcon" style="color: rgb(241,106,92);">' + cancelAlias + '</span>';
                    }
                }
                list += '   </h3>';
                list += '   <p>' + creatTimeStr(curList[i].auditResult.auditTime) + '</p>';
                list += '   <p class="msg-in-list">' + creatRejectMsg(curList[i], true, true) + '</p>';
                list += '</li>';
            }

            $('.Task-list').append(list);

            //更新列表后默认选中第一个
            // $('.Task-list li').eq(0).addClass('active');
            // currentTask = curList[0];
            // loadRecipeDetail();

            if (currentTask && currentTask.auditResult.id && isUpdate) {
                checkedById(currentTask.auditResult.id, curList);
            }

            if (currentTask && currentTask.auditResult.id) {
                $('#' + currentTask.auditResult.id).addClass('active');
            }
        }, "json")

    }

    //查找是否存在之前操作的处方并选中（全部栏有用）
    function checkedById(id, list) {
        for (var i = 0; i < list.length; i++) {
            if (id == list[i].auditResult.id) {
                currentTask = list[i];
                $('.Task-list li').eq(i).addClass('active').siblings().removeClass('active');
                if (currentTask.auditResult.source == '住院') {
                    loadOrderDetail();
                } else {
                    loadRecipeDetail();
                }
                isUpdate = false;
                return;
            }
        }
        //没有之前的记录，清除详情
        $(".main-info").html('');
    }
    //搜索关键字文本高亮处理
    function highLightText(oriText, keyword) {
        return oriText.replace(new RegExp(keyword, 'g'), '<span class="matchstr">' + keyword + '</span>');
    }
    //加载详情
    function loadRecipeDetail() {
        addLoading($('.main-info'));
        var detail = "";
        //基本信息
        var basicInfo = "";
        //打回信息
        var rejectInfo = "";
        if (currentTask) {
            //警示信息按等级从高到低排序
            if (currentTask.messageList && currentTask.messageList.length > 0) {
                var tempList = [];
                for (var i = currentTask.messageList.length - 1; i >= 0; i--) {
                    if (currentTask.messageList[i]) {
                        tempList.push(currentTask.messageList[i])
                    }
                }
                currentTask.messageList = tempList;
                currentTask.messageList = currentTask.messageList.sort(function (a, b) {
                    return b.severity - a.severity;
                });
            }
            //拼接基本信息
            basicInfo += '<div class="basic-info">';
            basicInfo += '  <div class="patient-info">' + currentTask.auditResult.name + ' ' + (currentTask.auditResult.sex == '2' ? '女' : currentTask.auditResult.sex == '1' ? '男' : '') + '  ' + '处方号:' + currentTask.auditResult.recipeId + '    <span>审核要求：<em>' + (currentTask.auditResult.messageStatus == 1 ? '可' + visaAlias : '必须' + modifyAlias) + '</em></span></div>';
            basicInfo += '  <div class="phar-info">';
            basicInfo += '      <span>审核药师：' + currentTask.auditResult.auditDoctorRealname + '</span>';
            basicInfo += '      <span>时间：' + creatTimeStr(currentTask.auditResult.auditTime) + '</span>';
            basicInfo += '  </div>';
            basicInfo += '</div>';

            //拼接打回信息
            rejectInfo += '<div class="reject-info">';
            rejectInfo += ' <div class="reject-engine-msg">';
            rejectInfo += '     <h3>用药问题</h3>';
            if (currentTask.messageList) {
                for (var i = 0; i < currentTask.messageList.length; i++) {
                    rejectInfo += '<p>' + creatRejectMsg(currentTask.messageList[i], true, false) + '</p>';
                }
            } else {
                rejectInfo += '<p>无</p>';
            }
            rejectInfo += ' </div>';
            rejectInfo += ' <div class="reject-msg">';
            rejectInfo += '     <h3>药师意见</h3>';
            rejectInfo += '     <p>' + creatRejectMsg(currentTask, false, true) + '</p>';
            rejectInfo += ' </div>';
            rejectInfo += '</div>';
        }
        $('.main-info').append(basicInfo + rejectInfo);
        var url = auditCenterUrl + '/api/v1/reject/getOptBackTaskDetail';
        $.get(url + '?optRecipeId=' + currentTask.auditResult.optRecipeId + '&t=' + new Date().getTime(), function (res) {
            $('.main-info').empty();
            var diagnoseStr = "无";
            var allergyStr = "无";
            var data = res.data;
            if (res.code != '200') {
                return;
            }
            //手动指定处方和草药嘱为空。防止快速切换在异步请求返回前完成导致的问题
            currentTask.Recipe = [];
            //处方基本信息
            if (data.sfPatient) {
                currentTask.RecipeInfo = data.sfPatient;
            } else {
                currentTask.RecipeInfo = {};
            };
            //处方诊断信息
            if (data.sfOptRecipe) {
                currentTask.sfOptRecipe = data.sfOptRecipe || [];
                diagnoseStr = currentTask.sfOptRecipe.diagnoseName || '';
            } else {
                diagnoseStr = '';
                currentTask.sfOptRecipe = {};
            };
            //处方过敏药物信息
            if (data.allergyList) {
                currentTask.allergyList = data.allergyList || [];
                if (currentTask.allergyList.length > 0) {
                    var allergyArr = [];
                    for (var i = 0; i < currentTask.allergyList.length; i++) {
                        allergyArr.push(currentTask.allergyList[i].allergyDrug);
                    }
                    allergyStr = allergyArr.join('、');
                };
            } else {
                allergyStr = '';
            };
            //药物处方列表
            if (data.mapItems) {
                var Recipe = data.mapItems || {};
                currentTask.Recipe = [];
                for (var key in Recipe) {
                    currentTask.Recipe = currentTask.Recipe.concat(Recipe[key]);
                }
            } else {
                currentTask.Recipe = [];
            }
            var isPregnantStatus = ['否', '是'], isLactationStatus = ['否', '是'];
            detail += basicInfo;
            detail += '<div class="details-info">';
            //处方基本信息
            detail += '     <table class="Task-info">';
            detail += '         <tr>';
            detail += '             <td><label>患者号：</label><span>' + (currentTask.RecipeInfo.patientId || '') + '</span></td>';
            detail += '             <td><label>年龄：</label><span>' + (currentTask.RecipeInfo.age || '') + '</span></td>';
            detail += '             <td><label>身高：</label><span>' + ((currentTask.RecipeInfo.heightType === 'ORIGINAL' || !currentTask.RecipeInfo.heightType) ? (currentTask.RecipeInfo.height || '') : (currentTask.RecipeInfo.heightType === 'PRESET' ? (currentTask.RecipeInfo.height ? currentTask.RecipeInfo.height + '(预设值)' : '') : (currentTask.RecipeInfo.height ? currentTask.RecipeInfo.height + '(计算值)' : ''))) + '</span></td>';
            detail += '             <td><label>体重：</label><span>' + ((currentTask.RecipeInfo.weightType === 'ORIGINAL' || !currentTask.RecipeInfo.weightType) ? (currentTask.RecipeInfo.weight || '') : (currentTask.RecipeInfo.weightType === 'PRESET' ? (currentTask.RecipeInfo.weight ? currentTask.RecipeInfo.weight + '(预设值)' : '') : (currentTask.RecipeInfo.weight ? currentTask.RecipeInfo.weight + '(计算值)' : ''))) + '</span></td>';
            detail += '             <td><label>怀孕：</label><span>' + (isPregnantStatus[currentTask.RecipeInfo.isPregnant] || '') + '</span></td>';
            detail += '             <td><label>孕期：</label><span>' + (currentTask.RecipeInfo.pregWeeks || '') + '</span></td>';
            detail += '             <td><label>哺乳：</label><span>' + (isLactationStatus[currentTask.RecipeInfo.isLactation] || '') + '</span></td>';
            detail += '             <td><label>体表面积：</label><span>' + (currentTask.RecipeInfo.bsa || '') + '</span></td>';
            detail += '         </tr>';
            detail += '         <tr>';
            detail += '             <td colspan="8"><label>诊断：</label><span>' + (diagnoseStr || ' ') + '</span><label style="margin-left: 20px;">过敏：</label><span>' + allergyStr + '</span></td>';
            detail += '         </tr>';
            detail += '     </table>';
            //处方药品信息
            detail += '     <table class="engine-msg">';
            detail += '         <tr><th>组号</th><th>药品名称</th><th>给药剂量</th><th>给药途径</th><th>给药频率</th></tr>';
            //处方
            if (currentTask.Recipe) {
                for (var i = 0; i < currentTask.Recipe.length; i++) {
                    detail += '     <tr>';
                    detail += '         <td>' + currentTask.Recipe[i].groupNo + '</td>';
                    detail += '         <td>' + currentTask.Recipe[i].drugName + '</td>';
                    detail += '         <td>' + currentTask.Recipe[i].drugDose + '</td>';
                    detail += '         <td>' + currentTask.Recipe[i].drugAdminrouteName + '</td>';
                    detail += '         <td>' + currentTask.Recipe[i].drugUsingFreq + '</td>';
                    detail += '     </tr>';
                }
            };
            detail += '     </table>';
            detail += rejectInfo;
            detail += '</div>';

            // if(currentTask.auditResult.source) {

            // } else {
            //     $('div.reply-revoke > button').text('撤销医嘱');
            // }
            // 产品需求 修改处方按钮 功能需求更改为 发送理由
            // $('div.reply-revoke > button').text(modifyAlias);
            $('div.reply-revoke > button').text(sendReason);
            // if (currentTask.auditResult.messageStatus) {
            $('div.reply-visa  > button').text(visaAlias);
            // 是否展示双签按钮逻辑
            if (data.rdsiType == '1') {
                $('div.reply-visa').hide();
            } else {
                $('div.reply-visa').show();
            }
            // } 
            // else {
            //     $('div.reply-visa  > button').text(sendReason);
            // }

            $('.main-info').append(detail);
            // 获取聊天信息
            getChatMessage(currentTask.auditResult.optRecipeId);
            _feedback();
            $('.react-module').show();
            //修正滚动条本身已经存在的问题
            fixedBasicInfo();
        });
    }

    // 加载聊天内容
    // 聊天记录区分药师和医生  来自审方客户端角色为医生 ，来自审方系统的角色为药师
    function loadChatInfo() {
        //聊天信息 
        $('.chat-info').remove();
        var chatInfo = "";
        if (chatMessage && chatMessage.length > 0) {
            chatInfo += '<div class="chat-info">';
            // 聊天记录 
            for (var i = 0; i < chatMessage.length; i++) {
                var roleType = chatMessage[i].senderRole;
                chatInfo += '   <div class="chat-box">';
                chatInfo += '       <div class="chat-title">';
                if (roleType == '药师') {
                    chatInfo += '       <div class="chat-icon chat-icon-pharmacist"></div>';
                } else {
                    chatInfo += '       <div class="chat-icon chat-icon-doctor"></div>';
                }
                chatInfo += '           <label>' + (chatMessage[i].senderRole || '') + ' ' + (chatMessage[i].senderName || '') + '</label>';
                chatInfo += '           <span>' + creatTimeStr(chatMessage[i].sendTime) + '</span>';
                chatInfo += '       </div>'
                chatInfo += '       <div class="chat-content">';
                chatInfo += '           <span>' + chatMessage[i].message + '</span>';
                chatInfo += '       </div>';
                chatInfo += '  </div>';
            }
            chatInfo += '</div>';
            $('.main-info').append(chatInfo);
        }
    }

    // 区分角色
    function distinguishRole(roleType) {
        if (roleType == '药师') {
            $('.chat-icon').addClass('chat-icon-pharmacist');
        }
        if (roleType == '医生') {
            $('.chat-icon').addClass('chat-icon-doctor');
        }
    }

    //加载详情
    function loadOrderDetail() {
        addLoading($('.main-info'));
        var detail = "";
        //基本信息
        var basicInfo = "";
        //打回信息
        var rejectInfo = "";
        if (currentTask) {
            //警示信息按等级从高到低排序
            if (currentTask.messageList && currentTask.messageList.length > 0) {
                var tempList = [];
                for (var i = currentTask.messageList.length - 1; i >= 0; i--) {
                    if (currentTask.messageList[i]) {
                        tempList.push(currentTask.messageList[i])
                    }
                }
                currentTask.messageList = tempList;
                currentTask.messageList = currentTask.messageList.sort(function (a, b) {
                    return b.severity - a.severity;
                });
            }
            //拼接基本信息
            basicInfo += '<div class="basic-info">';
            basicInfo += '  <div class="patient-info">' + currentTask.auditResult.inWardName + '　' + currentTask.auditResult.inWardBedNo + '床　' + currentTask.auditResult.name + '　' + (currentTask.auditResult.sex == 'F' ? '女' : '男') + '　<span>审核要求：<em>' + (currentTask.auditResult.messageStatus == 1 ? '可' + visaAlias : '必须' + cancelAlias) + '</em></span></div>';
            basicInfo += '  <div class="phar-info">';
            basicInfo += '      <span>审核药师：' + currentTask.auditResult.auditDoctorRealname + '</span>';
            basicInfo += '      <span>时间：' + creatTimeStr(currentTask.auditResult.auditTime) + '</span>';
            basicInfo += '  </div>';
            basicInfo += '</div>';

            //拼接打回信息
            rejectInfo += '<div class="reject-info">';
            rejectInfo += ' <div class="reject-engine-msg">';
            rejectInfo += '     <h3>用药问题</h3>';
            if (currentTask.messageList) {
                for (var i = 0; i < currentTask.messageList.length; i++) {
                    rejectInfo += '<p>' + creatRejectMsg(currentTask.messageList[i], true, false) + '</p>';
                }
            } else {
                rejectInfo += '<p>无</p>';
            }
            rejectInfo += ' </div>';
            rejectInfo += ' <div class="reject-msg">';
            rejectInfo += '     <h3>药师意见</h3>';
            rejectInfo += '     <p>' + creatRejectMsg(currentTask, false, true) + '</p>';
            rejectInfo += ' </div>';
            rejectInfo += '</div>';
        }
        var url = auditCenterUrl + "/api/v1/reject/getIptBackTaskDetail?engineId=" + currentTask.auditResult.engineId + '&groupNo=' + currentTask.auditResult.groupNo + '&t=' + new Date().getTime();
        $.get(url, function (res) {
            $('.main-info').empty();
            var diagnoseStr = "无";
            var allergyStr = "无";

            if (res.code != '200') {
                return;
            }
            var data = res.data;
            //手动指定医嘱和草药嘱为空。防止快速切换在异步请求返回前完成导致的问题
            currentTask.order = [];
            currentTask.herbOrder = [];
            //医嘱基本信息
            if (data.iptAllPatientVo) {
                currentTask.orderInfo = data.iptAllPatientVo || {};
            } else {
                currentTask.orderInfo = {};
            };
            //医嘱诊断信息
            if (data.diagnoseVoList) {
                currentTask.diagnoseList = data.diagnoseVoList || [];
                if (currentTask.diagnoseList.length > 0) {
                    var diagnoseArr = [];
                    for (var i = 0; i < currentTask.diagnoseList.length; i++) {
                        diagnoseArr.push(currentTask.diagnoseList[i].diagName);
                    }
                    diagnoseStr = diagnoseArr.join('、');
                };
            } else {
                diagnoseStr = '';
            };
            //医嘱过敏药物信息
            if (data.allergyVoList) {
                currentTask.allergyList = data.allergyVoList || [];
                if (currentTask.allergyList.length > 0) {
                    var allergyArr = [];
                    for (var i = 0; i < currentTask.allergyList.length; i++) {
                        allergyArr.push(currentTask.allergyList[i].allergyDrug);
                    }
                    allergyStr = allergyArr.join('、');
                };
            } else {
                allergyStr = '';
            };
            //药物医嘱列表
            if (data.orderVoList) {
                currentTask.order = data.orderVoList || {};
            } else {
                currentTask.order = {};
            };
            //草药嘱列表
            if (data.herbOrderVoList && data.herbOrderVoList.length > 0) {
                currentTask.herbOrder = data.herbOrderVoList[0];
            } else {
                currentTask.herbOrder = [];
            };

            var pregnancyStatus = ['否', '是'], breastFeedingStatus = ['否', '是'];
            detail += basicInfo;
            detail += '<div class="details-info">';
            //医嘱基本信息
            detail += '     <table class="Task-info">';
            detail += '         <tr>';
            detail += '             <td><label>患者号：</label><span>' + (currentTask.orderInfo.patientId || '') + '</span></td>';
            detail += '             <td><label>年龄：</label><span>' + (currentTask.orderInfo.ageStr || '') + '</span></td>';
            detail += '             <td><label>身高：</label><span>' + ((currentTask.orderInfo.heightType === 'ORIGINAL' || !currentTask.orderInfo.heightType) ? (currentTask.orderInfo.height || '') : (currentTask.orderInfo.heightType === 'PRESET' ? (currentTask.orderInfo.height ? currentTask.orderInfo.height + '(预设值)' : '') : (currentTask.orderInfo.height ? currentTask.orderInfo.height + '(计算值)' : ''))) + '</span></td>';
            detail += '             <td><label>体重：</label><span>' + ((currentTask.orderInfo.weightType === 'ORIGINAL' || !currentTask.orderInfo.weightType) ? (currentTask.orderInfo.weight || '') : (currentTask.orderInfo.weightType === 'PRESET' ? (currentTask.orderInfo.weight ? currentTask.orderInfo.weight + '(预设值)' : '') : (currentTask.orderInfo.weight ? currentTask.orderInfo.weight + '(计算值)' : ''))) + '</span></td>';
            detail += '             <td><label>怀孕：</label><span>' + (pregnancyStatus[currentTask.orderInfo.pregnancy] || '') + '</span></td>';
            detail += '             <td><label>孕期：</label><span>' + (currentTask.orderInfo.timeOfPreg || '') + '</span></td>';
            detail += '             <td><label>哺乳：</label><span>' + (breastFeedingStatus[currentTask.orderInfo.breastFeeding] || '') + '</span></td>';
            detail += '             <td><label>体表面积：</label><span>' + (currentTask.orderInfo.bsa || '') + '</span></td>';
            detail += '         </tr>';
            detail += '         <tr>';
            detail += '             <td colspan="8"><label>诊断：</label><span>' + (diagnoseStr || ' ') + '</span><label style="margin-left: 20px;">过敏：</label><span>' + allergyStr + '</span></td>';
            detail += '         </tr>';
            detail += '     </table>';
            //医嘱药品信息
            detail += '     <table class="engine-msg">';
            detail += '         <tr><th>组号</th><th>医嘱类型</th><th>药品名称</th><th>给药剂量</th><th>给药途径</th><th>给药频率</th><th>医生</th></tr>';
            //医嘱
            if (currentTask.order) {
                for (var i = 0; i < currentTask.order.length; i++) {
                    detail += '     <tr>';
                    detail += '         <td>' + currentTask.order[i].groupNo + '</td>';
                    detail += '         <td>' + currentTask.order[i].orderType + '</td>';
                    detail += '         <td>' + currentTask.order[i].drugName + '</td>';
                    detail += '         <td>' + currentTask.order[i].drugDose + '</td>';
                    detail += '         <td>' + currentTask.order[i].drugAdminRouteName + '</td>';
                    detail += '         <td>' + currentTask.order[i].drugUsingFreq + '</td>';
                    detail += '         <td>' + currentTask.order[i].orderDocName + '</td>';
                    detail += '     </tr>';
                }
            };
            //草药嘱
            if (currentTask.herbOrder && currentTask.herbOrder.itemList) {
                var herbOrder = currentTask.herbOrder.itemList;
                for (var i = 0; i < herbOrder.length; i++) {
                    detail += '     <tr>';
                    detail += '         <td>' + herbOrder[i].groupNo + '</td>';
                    detail += '         <td>' + currentTask.herbOrder.orderType + '</td>';
                    detail += '         <td>' + herbOrder[i].drugName + '</td>';
                    detail += '         <td>' + herbOrder[i].drugDose + '</td>';
                    detail += '         <td>' + herbOrder[i].drugAdminRouteName + '</td>';
                    detail += '         <td>' + herbOrder[i].drugUsingFreq + '</td>';
                    detail += '         <td>' + currentTask.herbOrder.orderDocName + '</td>';
                    detail += '     </tr>';
                }
            }
            detail += '     </table>';
            detail += rejectInfo;
            detail += '</div>';
            // 产品要求暂时隐藏撤销医嘱按钮 更改为发送理由功能
            // $('div.reply-revoke > button').text(cancelAlias);
            $('div.reply-revoke > button').text(sendReason);
            // if (currentTask.auditResult.messageStatus) {
            $('div.reply-visa  > button').text(visaAlias);
            // 是否展示双签按钮逻辑
            if (data.rdsiType == '1') {
                $('div.reply-visa').hide();
            } else {
                $('div.reply-visa').show();
            }
            // } 
            // else {
            //     $('div.reply-visa  > button').text(sendReason);
            // }
            $('.main-info').append(detail);
            // 获取聊天记录
            getChatMessage(currentTask.auditResult.engineId);
            _feedback();
            $('.react-module').show();
            //修正滚动条本身已经存在的问题
            fixedBasicInfo();
        })
    }

    /**
     * 医生反馈
     */
    var feedbackParma = {
        //taskId 任务ID
        //zoneId 院区id
        //patientId 患者号
        //eventNo 就诊流水号
        //source 来源 （注：当前版本只有住院，默认为 3）
        source: 3,
        //kfDocId 开放医生id
        kfDocId: userId,
        //docId 医生id
        //docName 医生姓名
        docName: userName
        //isHerb 是否是草药嘱
        //groupNo 组号
        //recipeId 处方id
        //message 回复信息
        //status 操作状态  1 => 双签名  2 => 修改
        //password 验证时输入的密码
        //RecipeList: string[] 处方ids 
    };
    var feedbackStatus;

    //修改处方/撤销医嘱功能更改为  ==> 发送理由
    $('.reply-revoke').on('click', function () {
        if (!currentTask) {
            alert('请先选择处方。');
            return;
        };

        // 隐藏修改处方/撤销医嘱功能
        // feedbackStatus = 0;
        // if (currentTask.auditResult.source == '门诊' || currentTask.auditResult.source == '急诊') {
        //     $('.prompt-text h3').html('请在开方系统修改处方。');
        //     $('.prompt').show();
        //     $('.prompt-cancel').hide();
        // } else {
        //     $('.prompt-text h3').html('确定要' + this.innerText + '吗?');
        //     $('.prompt-cancel').show();
        //     $('.prompt').show();
        // }

        // 发送理由功能
        sendChatMessage();
    });
    //双签名
    $('.reply-visa').on('click', function () {
        if (!currentTask) {
            alert('请先选择处方。');
            return;
        };
        if (currentTask.auditResult.messageStatus !== 0) {
            feedbackStatus = 1;
            $('.prompt-text h3').html('确定' + visaAlias + '吗?');
            $('.prompt-cancel').show();
            $('.prompt').show();
        }
    });
    //取消操作
    $('.prompt-cancel').on('click', function () {
        feedbackStatus = undefined;
        $('.prompt').hide();
    });
    //执行操作
    $('.prompt-verify').on('click', function () {
        $('.prompt').hide();
        feedbackParma.docId = null;
        window.clearTimeout(polledChatTask);
        polledChatTask = null;
        $('.chat-info').remove();
        if ((currentTask.auditResult.source == '门诊' || currentTask.auditResult.source == '急诊') && optIsVerify) {
            $('.verify-module').show();
        } else if ((currentTask.auditResult.source == '门诊' || currentTask.auditResult.source == '急诊') && !optIsVerify) {
            feedback(feedbackStatus, currentTask);
        }
        if (currentTask.auditResult.source == '住院' && iptIsVerify) {
            $('.verify-module').show();
        } else if (currentTask.auditResult.source == '住院' && !iptIsVerify) {
            feedback(feedbackStatus, currentTask);
        }
        // $('.verify-module').show();
        //默认确认按钮不能点击
        $(".doctorId").val('');
        $(".doctorPwd").val('');
        $(".pwd-verify").prop('disabled', true).addClass('disabled');
    });

    /**
     *验证工号密码 => 非标
     */
    $(".doctorId, .doctorPwd").on('keyup', function () {
        var doctorId = $.trim($(".doctorId").val());
        doctorPwd = $(".doctorPwd").val();

        if (doctorId && doctorPwd) {
            $(".pwd-verify").prop('disabled', false).removeClass('disabled');
        } else {
            $(".pwd-verify").prop('disabled', true).addClass('disabled');
        }
    });
    //提交验证
    $(".pwd-verify").on('click', function () {
        var doctorId = $.trim($(".doctorId").val());
        doctorPwd = $(".doctorPwd").val();

        $('.err-msg').hide(); //隐藏错误信息

        feedbackParma.docId = doctorId; //操作用户的docId
        feedbackParma.password = doctorPwd;

        feedback(feedbackStatus, currentTask);
    });
    //取消验证
    $(".pwd-cancel, .close").on('click', function () {
        $('.verify-module').hide();
    });

    //展示医生操作结果
    function showRejcetInfo() {
        if (currentTask.auditResult.rejectStatus == 1) {
            $('.fb-result').removeClass('revoke').addClass('visa').html(visaAlias);
        } else {
            $('.fb-result').removeClass('visa').addClass('revoke').html(currentTask.auditResult.source == '住院' ? cancelAlias : modifyAlias);
        }
        var processInfo = '<span>处理人：' + (currentTask.auditResult.rejectDoctorName ? currentTask.auditResult.rejectDoctorName + (currentTask.auditResult.rejectDoctorId ? '（' + currentTask.auditResult.rejectDoctorId + '）' : '') : '医生') + '</span><span>处理时间：' + creatTimeStr(currentTask.auditResult.rejectTime) + '</span>';
        $('.feedback-info').empty().append(processInfo);

        $('.feedback-msg').html('留言：' + (currentTask.auditResult.rejectMessage || '无'));
    }

    function feedback(status, currentTask) {
        if (currentTask.auditResult.source == "门诊" || currentTask.auditResult.source == '急诊') {
            feedbackParma.taskId = currentTask.auditResult.optRecipeId;

            feedbackParma.kfDocId = currentTask.auditResult.auditDoctorId;
            feedbackParma.docName = userName;
            feedbackParma.groupNo = currentTask.Recipe[0].groupNo;
            feedbackParma.recipeId = currentTask.auditResult.recipeId;
            feedbackParma.message = getReplyMsg();
            feedbackParma.status = status;

        } else {
            feedbackParma.taskId = currentTask.auditResult.engineId;
            feedbackParma.isHerb = (currentTask.order && currentTask.order.length > 0) ? 0 : 1;
            feedbackParma.groupNo = feedbackParma.isHerb ? currentTask.herbOrder.itemList[0].groupNo : currentTask.auditResult.groupNo;
            // feedbackParma.recipeId = 
            feedbackParma.message = getReplyMsg();
            feedbackParma.status = status;

            if (feedbackParma.isHerb) {
                feedbackParma.orderList = [].concat(currentTask.herbOrder.orderId);
            } else {
                feedbackParma.orderList = [];
                for (var i = 0; i < currentTask.order.length; i++) {
                    feedbackParma.orderList.push(currentTask.order[i].orderId);
                }
            }
        }

        feedbackParma.docId = feedbackParma.docId || userId;
        feedbackParma.source = currentTask.auditResult.source == "门诊" ? 1 : currentTask.auditResult.source == "急诊" ? 2 : 3;
        feedbackParma.zoneId = currentTask.auditResult.zoneId;
        feedbackParma.patientId = currentTask.auditResult.patientId;
        feedbackParma.eventNo = currentTask.auditResult.eventNo;

        $.ajax({
            url: auditCenterUrl + '/api/v1/doctorOperation?t=' + new Date().getTime(),
            type: "POST",
            data: JSON.stringify(feedbackParma),
            dataType: 'json',
            success: function (json) {
                if (json.code == '200') {
                    $('.verify-module').hide();
                    $('.react-module').hide();
                    window.clearTimeout(polledChatTask);
                    polledChatTask = null;
                    // currentTask.auditResult.rejectStatus = status;
                    // currentTask.auditResult.docName = userName;
                    // currentTask.auditResult.userId = userId;
                    // currentTask.auditResult.rejectMsg = feedbackParma.message;
                    // currentTask.auditResult.rejectTime = new Date().getTime();
                    $('.reply-msg').val('如有必要,请输入理由').addClass('reply-msg-txt');
                    // var resultIcon = '   <span class="state ' + (status == 1 ? 'state-visa' : 'state-revoke') + ' ">' + (status == 1 ? '双签' : '修改') + '</span>';
                    $('.tips').removeClass('failed').addClass('sucess').fadeIn().find('span').html('操作成功');
                    //控制提示消失
                    setTimeout(function () {
                        $('.tips').fadeOut();
                    }, 3000);
                    //重新获取列表
                    // setTimeout(function () {
                    //     getCounts();
                    //     loadList();
                    // }, 1500)
                    isUpdate = true;
                    addLoading($('.Task-list-container'));
                    getCounts();
                    loadList();
                    removeLoading();
                    //更新列表信息
                    // $('.Task-list .active h3 .icon').remove();
                    // $('.Task-list .active h3').append(resultIcon);
                    //更新详情
                    //loadRecipeDetail();

                    // $('.feedback').show();
                    // $('.reply').hide();
                    // showRejcetInfo();
                } else if (json.code == '403' || json.code == '406') {
                    $('.tips').removeClass('sucess').addClass('failed').fadeIn().find('span').html(json.message ? json.message : '工号或密码错误');
                    setTimeout(function () {
                        $('.tips').fadeOut();
                    }, 3000);
                    // $('.err-msg').show();    
                } else if (json.code > 500) {
                    $('.tips').removeClass('sucess').addClass('failed').fadeIn().find('span').html('操作失败');
                    setTimeout(function () {
                        $('.tips').fadeOut();
                    }, 3000);
                } else {
                    $('.tips').removeClass('sucess').addClass('failed').fadeIn().find('span').html(json.message ? json.message : '操作失败');
                    setTimeout(function () {
                        $('.tips').fadeOut();
                    }, 3000);
                }
            },
            error: function (res) {
                $('.tips').removeClass('sucess').addClass('failed').fadeIn().find('span').html('请求失败');
                setTimeout(function () {
                    $('.tips').fadeOut();
                }, 3000);
            }
        })
    }
    /**
     * Loading
     * @target => 局部刷新容器  jQuery对象
     */
    function addLoading(target) {
        var loadingComponent = $("<div class='loading'></div>");
        if (!target || target instanceof jQuery)
            target.append(loadingComponent);
    }

    function removeLoading() {
        if ($('.loading'))
            $('.loading').remove();
    }
    /**
     * 方法
     */
    //构建时间字符串
    function creatTimeStr(date) {
        if (!date) { return ''; }
        var d = new Date(date);

        return d.getFullYear() + "-" + timeFormat(d.getMonth() + 1) + "-" + timeFormat(d.getDate()) + ' ' + timeFormat(d.getHours()) + ':' + timeFormat(d.getMinutes());
    }

    function timeFormat(time) {
        if (time < 10) {
            return '0' + time;
        } else {
            return time;
        }
    }
    //构建列表中用药问题
    function creatRejectMsg(obj, msg, opinian) {
        //勾选的警示信息 或 打回意见
        if (msg && opinian) {
            if (obj.auditResult.auditResult || obj.auditResult.auditOpinion) {
                return obj.auditResult.auditResult || obj.auditResult.auditOpinion;
            } else if (obj.msgList && obj.msgList.length > 0) {
                var msg = obj.msgList[0];
                if (!obj.msgList[0]) {
                    return '';
                }
                return (msg.severity ? msg.severity + '、' : '') + (msg.analysisResultType ? msg.analysisResultType + '： ' : '') + (msg.drugName || msg.hisDrugName || '') + ' ' + (msg.errorInfo || '') + ' ' + (msg.advice || '');
            } else if (obj.messageList && obj.messageList.length > 0) {
                var msg = obj.messageList[0];
                if (!obj.messageList[0]) {
                    return '';
                }
                return (msg.severity ? msg.severity + '、' : '') + (msg.analysisResultType ? msg.analysisResultType + '： ' : '') + (msg.drugName || msg.hisDrugName || '') + ' ' + (msg.errorInfo || '') + ' ' + (msg.advice || '');
            } else {
                return '无';
            }
        }
        //仅勾选的警示信息
        if (msg && !opinian) {
            if (!obj) {
                return '';
            }
            return obj.severity + '、' + (obj.analysisResultType ? obj.analysisResultType + '： ' : '') + (obj.drugName || obj.hisDrugName || '') + ' ' + obj.errorInfo + ' ' + obj.advice;
        }
        //仅打回意见
        if (!msg && opinian) {
            return obj.auditResult.auditResult ? obj.auditResult.auditResult : (obj.auditResult.auditOpinion ? obj.auditResult.auditOpinion : '无');
        }
    }
    //获取url参数
    function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return decodeURI(r[2]);
        return undefined;
    }

    //初始化方法
    (function init() {
        calcSize();
        window.clearTimeout(polledChatTask);
        polledChatTask = null;
        // canCancel();
        // getVisaName();
        // getCancelName();
        $.get(auditCenterUrl + '/api/v1/config/clientDocVerify', function (v1) {
            if (v1.code == '200') {
                iptIsVerify = v1.data.iptIsVerify;
                optIsVerify = v1.data.optIsVerify;
            };
        })
        $.get(auditCenterUrl + '/api/v1/config/cancelName', function (v2) {
            if (v2.code == '200' && v2.data) {
                cancelAlias = v2.data;
            };
        })
        $.get(auditCenterUrl + '/api/v1/config/doubleSignName', function (v3) {
            if (v3.code == '200' && v3.data) {
                visaAlias = v3.data;
                $('.reply-visa button').text(visaAlias);
            };
        })
        $.get(auditCenterUrl + '/api/v1/config/modifyName', function (v4) {
            if (v4.code == '200' && v4.data) {
                modifyAlias = v4.data;
            };
        })


        $('.react-module').hide();

        addLoading($('.Task-list-container'));
        getCounts();
        loadList();
        removeLoading();

        setInterval(function () {
            getCounts();
            loadList();
        }, 5000)

        // 轮询获取聊天信息
        polledGetChatInfo = function () {
            polledChatTask = setTimeout(function () {
                if (currentTask && currentTask.auditResult && currentTask.auditResult.source) {
                    getChatMessage(getAttachKey());
                    window.clearTimeout(polledChatTask);
                    polledChatTask = null;
                    polledGetChatInfo();
                }
            }, 2000);
        }
    }());
});
